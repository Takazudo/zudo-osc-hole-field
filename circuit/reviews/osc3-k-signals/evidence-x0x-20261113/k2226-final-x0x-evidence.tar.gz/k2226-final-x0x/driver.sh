#!/bin/bash
# K2226 sharded complete-warning audit driver (#311). Two lanes: zones | six others serially.
cd /home/takazudo/repos/circuits/zudo-osc-hole-field/worktrees/k2226-final-x0x || exit 1
D=.circuit-cache/k2226-data
B=$D/osc-core-grid-osc3-wsl-20261109a-start/osc-core.kicad_pcb
A=$D/osc-core-grid-signals-12-verify/osc-core.kicad_pcb
O=.circuit-cache/k2226-final-x0x
PY=.circuit-cache/venv/bin/python
mkdir -p $O/units
L=$O/driver.log
log(){ echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) $*" >> $L; }
headroom_mb(){ awk '/MemAvailable/{a=$2}/SwapFree/{s=$2}END{print int((a+s)/1024)}' /proc/meminfo; }
run(){ # unit
  local U=$1 N=${1//:/-}
  log "start unit=$U out=$O/units/$N headroom_mb=$(headroom_mb)"
  local t0=$(date +%s)
  $PY scripts/pcbgen/warning_shards.py run-unit --stage-removals-from-delta --unit $U $B $A $O/units/$N > $O/$N.log 2>&1
  local rc=$?
  log "end unit=$U rc=$rc wall_s=$(( $(date +%s)-t0 ))"
  echo $rc > $O/$N.rc
}
log "driver start pid=$$ commit=$(git rev-parse HEAD)"
run zones & ZP=$!
log "lane-zones pid=$ZP"
sleep 60
for U in silk:0:1184 silk:1184:2368 silk:2368:3552 silk:3552:4645 holes-before holes-after; do
  while kill -0 $ZP 2>/dev/null && [ "$(headroom_mb)" -lt 2048 ]; do
    log "lane-b waiting: headroom_mb=$(headroom_mb) < 2048 (serial until zones ends)"; sleep 300; done
  run $U
done
log "lane-b done"
wait $ZP
log "driver end"
