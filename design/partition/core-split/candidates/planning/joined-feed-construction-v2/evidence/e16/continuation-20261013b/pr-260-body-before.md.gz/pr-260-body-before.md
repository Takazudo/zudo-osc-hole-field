## Latest (dd3ef71): finite coverage complete, copper requirement fails, KB pilot closes 6 pads

The PR stays draft and unmerged. KEEP_K1402_INCUMBENT stands. Native calls: 0. Canonical `boards/`, `placements.lock.json` and `decision.json` are unchanged. G2 stays OPEN. This continuation follows the [#253 plan](https://github.com/Takazudo/zudo-osc-hole-field/issues/253#issuecomment-6130087762); details are in `joined-feed-construction-v2/WORK.md` and `evidence/e16/continuation-20261013/index.json`.

| Item | Result |
| --- | --- |
| Independent t2 replay | **Reproduced on both boards.** Per-round residual identities, both delta spans, every access report, base copper and the final graph/census all match; 29 steps ≤102 s / 1.34 GiB. `compare_replay.py` now fails closed (12 regressions). |
| Finite coverage at t2 | **Complete.** All 3,155 source-connected pads and all 12 terminals have finite paths. The census (3,849 / 682 residuals) is unchanged. The old model's 552 omissions are reproduced and classified: 546 sub-pitch sheet necks, 6 barrels without a cell. |
| Coupled KA–KB matrix | **21 states executed** (3 process cases × 7 return states); all-three-open classified as floating. Worst rail-minus-local-ground error ≤0.78 mV over 1,294 pads (≤1.55 mV with a single-land source), in a lower-load scenario only. |
| Copper requirement (1 mΩ rail / 0.5 mΩ AGND, once per path) | **Fails.** Every pad fails in the nominal and thin cases; 524/525 fail in the legacy case. The KA trunk from the source lands to the CS247 terminals alone exceeds the allowance on every net, case, stack and source variant. |
| Unserved supported load | +12V 90.8 mA and −12V 101.0 mA sit on structurally unresolved pads. |
| KB pilot (U4320.14, +5V) | **Credited.** One sealed, reviewed 7.49 mm F.Cu corridor closed 6 pads with 0 newly disconnected (KB 486 → 480, separate P1 record). The new pads see 28.8–31.3 mΩ. |
| KA pilot (U2314.11, −12V) | **No legal corridor within the sealed limits.** The dimensioned change: removing AGND via `1e1b90ef`'s In3 annulus joins the island. |
| Declared numerical tolerances | Global KCL, wire balance, reciprocity, reduction vs monolithic, mesh (≤4.2% refine / ≤1.1% shift) all met. **Node KCL is NOT MET:** it sits at the double-precision floor (≤17.5 ε per row). **Energy balance is NOT MET in one case** (1.64e-9 vs 1e-9). |

- **Current ledger.** One signed record per rail pad per scenario. Device KCL is exactly zero, and planning totals are never divided among pads. Most supply current is unmapped, so full-scope budget acceptance is false. The EL ceiling is kept as a separate external demand.
- **Wires and source.** Each wire's bulk is charged once and each termination once per board; the old per-board lump double-charged both. The KA source is conditional: an ideal tie of the main lands. A single-land run shows that tie is optimistic.
- **Process evidence.** JLCPCB's ≤0.5 mm limit is a hole limit and covers epoxy fill. "≥5 µm hole surface copper" is not a wall minimum. Fill-by-default on 6+ layers, the 2 oz PTH ring, minimum plating and the 2 oz six-layer stack remain open. No supplier contact.
- **Reviews.** Five independent reviews ran: geometry/numerics, currents/process, pilot geometry, sealed corridor and final claims. Each confirmed defect was fixed or is reported here: tangent contacts conducting, held lands spilling past their copper, preflight same-net drills, unbound provenance, and tolerance claims.
- **Native work.** A concrete descriptor is prepared (`continuation-20261013/native-descriptor.json`). Its admission run-ID/SHA/hook fields are unfilled and its materializer phase is NOT IMPLEMENTED. Nothing was admitted or dispatched.

**Checks at 0ad49dd, clean tree:**
- `pnpm circuit:check`: PASS, before and after
- Python suite: 1,620 tests, PASS
- `pnpm check`: PASS
- `regen-all.sh --check`: PASS, no tracked changes
- Native, retained-artifact and CI at this head (`[skip ci]`): NOT RUN

**Remaining gates:**
- G2 power service: structural residuals (KA 196, KB 480 in P1), copper requirement, unmapped current, GH 0.5 A NOT EVALUATED.
- G3/G4 native: NOT RUN / NOT ADMITTED.
- G6 bench: NOT RUN.
- Manufacturing qualification: open.

---

## Prior (8ca91b4): E16 leaves KA 196 / KB 486 pads unresolved; finite network begun but partial

The PR stays draft and unmerged. Native calls: 0. KEEP_K1402_INCUMBENT stands. Canonical `boards/`, `placements.lock.json` and `decision.json` are unchanged. Details are in `design/partition/core-split/candidates/planning/joined-feed-construction-v2/WORK.md` and `evidence/e16/`.

| Round | KA unresolved (direct / supp) | KB unresolved (direct / supp) | Newly disconnected |
| --- | --- | --- | --- |
| r3 (retained) | 226 (166 / 60) | 521 (372 / 149) | 0 / 0 |
| r4, r3 method repeated | 218 (161 / 57) | 511 (363 / 148) | 0 / 0 |
| t1, one representative pin per board | 217 (160 / 57) | 510 (362 / 148) | 0 / 0 |
| t2, shared access via on all residuals | **196 (144 / 52)** | **486 (343 / 143)** | 0 / 0 |

- **KB replay done.** Both boards replay independently from tracked files and match the retained base–r3 by content. r4–t2 have one execution each.
- **Two-face through orphan transitions resolves 0 of 24.** This is a recorded negative. The new mechanism that works is a pad-face route onto an existing feed-connected same-net via, exempting only that via's own bore.
- **Finite network is conditional and partial.** It is not a bound and not compliance. KB AGND is not shown within 20 mV (model figure 25.0 mV), and the +5V/−12V coverage is incomplete.
- **Process corrections.** JLCPCB advertises 2 oz inner copper, and 18 µm is an average plating, not a minimum. The 2 oz annular ring of ≥0.254 mm versus the 0.15 mm access-via ring is now an open question.
- **Checks.** NOT RUN: retained-artifact tests (preserved inputs absent), board native CI (no exact-run admission) and CI at this head (`[skip ci]`).

## Prior (V15, historical; inputs unrecoverable): complete physical-pad census; 604 feed connections added, 275 remain

Pinned source/evidence checkpoint: **`7e07b9790b867a6c1823e71b021705d5ca586346`**. [V15 evidence ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/7e07b9790b867a6c1823e71b021705d5ca586346/design/partition/core-split/candidates/planning/joined-feed-construction-v2/evidence/access-v15-index.json) · [Active work and limits](https://github.com/Takazudo/zudo-osc-hole-field/blob/7e07b9790b867a6c1823e71b021705d5ca586346/design/partition/core-split/candidates/planning/joined-feed-construction-v2/WORK.md) · [Independent full port review](https://github.com/Takazudo/zudo-osc-hole-field/blob/7e07b9790b867a6c1823e71b021705d5ca586346/design/partition/core-split/candidates/planning/joined-feed-construction-v2/evidence/mandatory-physical-ports-review.json) · [31 passing source regressions](https://github.com/Takazudo/zudo-osc-hole-field/blob/7e07b9790b867a6c1823e71b021705d5ca586346/design/partition/core-split/candidates/planning/joined-feed-construction-v2/evidence/access-v15-checks.json).

The owner's continuation remains active. Candidate05's complete wire/carrier source geometry is retained at `e59512bc2d150f9ef85913a226c297c4bcf4b361`; geometry screens are conditional and do not establish strength or physical process qualification.

**The whole electrical candidate is not accepted.** Complete drill checks rejected the earlier v9 local-via epoch. Corrected placement preserves original copper; explicitly modeled new staged transfers have dielectric-only annular walls and continuous0.07mm endpoint copper caps. Unspecified fill conductivity is not credited, and registration/manufacturing remain unqualified.

The independent census authenticates **3849 actual four-rail pads**, including GH/main/bypass pads omitted by the direct IC/current roster. Eight DNP capacitor pads remain passive copper obligations with no invented active injection. V14 had879 disconnected physical pads. V15's bounded cap/clip/full-graph/census evaluation confirms **604 additional feed connections**, leaving:

| Board | All unresolved physical pads | Direct-load subset | Supplemental subset |
|---|---:|---:|---:|
| KA | 58 | 41 | 17 |
| KB | 217 | 69 | 148 |
| Total | **275** | **110** | **165** |

Every remaining pad has an exact identity/component witness in the retained ledger. Local routing now targets only objects proved feed-connected by the whole graph. A local via or constructor receipt alone supplies no closure credit. Endpoint-cap and via field subcalculations are progressing, but actual contact/bulk/sheet composition and the complete signed-load verdict remain required; no equal return-current sharing is assumed.

Validation:31 packet regressions, independent source/census reviews, and the previously passing `pnpm circuit:check`/`pnpm check`. Sealed V15 source children completed within42.42s and1.48GiB. Native/F3 trials, canonical adoption, physical qualification and merge remain unperformed. This is a progress checkpoint; construction and electrical proof continue.

## Prior: one whole-F3 eastern audit completed; candidate rejected (#245)

**Reject this exact rigid transform.** The owner-approved 171-part / 502-pad relocation (+71.25,−85.85)mm completed once in 10.692 s, with 697,300 KiB peak RSS, under one worker / 2 GiB / 180 s. Zero retries, alternative poses, routing searches or native calls.

Measured failures: **24 location-dependent courtyard conflicts**, plus the inherited 0.349999 mm internal gap; **10 reservation overlaps and 3 service-hole collisions**. These fixed two-A obstacles independently reject the placement. Bounding-box fit did not imply physical fit. All internal relative geometry stayed fixed; prior fixed-rail access diagnoses are not automatically portable to the new location, and no access solver was rerun.

All 4,491 internal copper objects (4,210 segments / 281 vias) passed source contact-closure classification in 139 components and were translated only in the disposable source model. Their destination conflicts and native/zone gates prevent acceptance. The audit records 112 lost original fixed-copper contacts (35 signal / 77 rail), involving 89 moved pads / 109 fixed objects; one new AGND contact does not restore them. Complete 18-signal / seven-header / three-rail inventories retained. Full accepted 133,902-object hashes and 13,406 pad records authenticated; all 3,793 footprint blocks match canonical source. Other-candidate copper/pad conflicts are explicitly separate from retained two-A conflicts.

[Readable audited outcome](https://github.com/Takazudo/zudo-osc-hole-field/blob/8aa322d3ef37e3675acfb40ddd6747f7aae902d7/design/partition/core-split/candidates/pilots/f3-whole-east-v1/README.md) · [placement illustration](https://github.com/Takazudo/zudo-osc-hole-field/blob/8aa322d3ef37e3675acfb40ddd6747f7aae902d7/design/partition/core-split/candidates/pilots/f3-whole-east-v1/audited-placement.svg) · [exact placement witnesses](https://github.com/Takazudo/zudo-osc-hole-field/blob/8aa322d3ef37e3675acfb40ddd6747f7aae902d7/design/partition/core-split/candidates/pilots/f3-whole-east-v1/evidence/placement.json) · [copper/contact classification](https://github.com/Takazudo/zudo-osc-hole-field/blob/8aa322d3ef37e3675acfb40ddd6747f7aae902d7/design/partition/core-split/candidates/pilots/f3-whole-east-v1/evidence/internal-copper-classification.json.gz) · [boundary obligations](https://github.com/Takazudo/zudo-osc-hole-field/blob/8aa322d3ef37e3675acfb40ddd6747f7aae902d7/design/partition/core-split/candidates/pilots/f3-whole-east-v1/evidence/boundary-net-obligations.json.gz) · [sealed ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/8aa322d3ef37e3675acfb40ddd6747f7aae902d7/design/partition/core-split/candidates/pilots/f3-whole-east-v1/ledger.json).

Source commit `e565e2783a442ce2e732ed25b7f4f6b0417ecc92`; evidence commit `8aa322d3ef37e3675acfb40ddd6747f7aae902d7`. Independent source/result/report reviews PASS. Four synthetic tests, pnpm check, pre/post circuit checks and frozen-baseline verification PASS (manual inventory: 68 lines, zero placements, no schematic binding). Canonical boards/copper, panel/harness/full pin order and accepted 117/129/1402 receipts unchanged. No fresh native/zone/refill/DRC/parity/full-warning/eligibility result, regeneration or merge.

**Stopped at the decision boundary:** retire this exact eastern transform. Owner may authorize a new planning step for internal F3 repacking with fixed non-F3/service/panel/interface geometry and an exact copper reconstruction contract. No second experiment or broader search follows; this outcome does not prove all whole-F3 relocations impossible.

---

## Prior: reviewed F3 alternative-site plan (#245)

**Planning complete; next experiment not authorized or executed.** The failed local proposal is retired. Four approaches are compared in the [readable plan](https://github.com/Takazudo/zudo-osc-hole-field/blob/c3e4bc95858ac573332b47bd34032b2358fa009c/design/partition/core-split/candidates/planning/f3-next-approach/README.md), with a [source-window overview](https://github.com/Takazudo/zudo-osc-hole-field/blob/c3e4bc95858ac573332b47bd34032b2358fa009c/design/partition/core-split/candidates/planning/f3-next-approach/source-windows.svg), [exact electrical boundary](https://github.com/Takazudo/zudo-osc-hole-field/blob/c3e4bc95858ac573332b47bd34032b2358fa009c/design/partition/core-split/candidates/planning/f3-next-approach/whole-f3-boundary.json), [dormant experiment contract](https://github.com/Takazudo/zudo-osc-hole-field/blob/c3e4bc95858ac573332b47bd34032b2358fa009c/design/partition/core-split/candidates/planning/f3-next-approach/next-experiment.json) and [sealed ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/c3e4bc95858ac573332b47bd34032b2358fa009c/design/partition/core-split/candidates/planning/f3-next-approach/ledger.json).

Recommend one source-only audit of rigid whole-F3 relocation into eastern two-A: exactly171 source parts,122 internal nets/4491 potentially retainable original copper records,18 signal interfaces at **seven fixed headers**, plus three shared rails. Proposed translation (+71.25,−85.85)mm fits the region only by bounding-box arithmetic. Existing N1/M4 circuitry, reservations and copper remain fixed; no moved geometry has been evaluated. Internal U2309/access failures, BP span and the strict inherited courtyard failure would remain. This is an obstruction/contact accounting experiment, not a claim of placement fit or routability.

The future bound is one authored transform, one source worker/2GiB/180s, zero alternatives/searches/native calls/retries. An owner must separately authorize the disposable whole171 proposal, including release of U2306 and seven internal trimmers; no cuts, canonical adoption, native run or merge follows. Resource exhaustion must return INCOMPLETE. No native slot requested.

Reviewed planning commit `c3e4bc95858ac573332b47bd34032b2358fa009c`; source closeout `1bc168efb41c369d1598733719b6a4befcc6e7cb`. Independent planning/boundary reviews PASS, housekeeping addressed; pnpm check, pre/post circuit checks and frozen-baseline verification PASS. All canonical inputs unchanged, accepted117/129/1402 receipts retained. No fresh native connectivity, DRC/parity, refill or full-warning/eligibility result. Full regeneration not run because native execution is outside this planning scope.

---

## Prior: reviewed local-site copper-impact decision (#245)

**Recommendation: retire this specific local proposal and preserve accepted copper.** One group was selected from saved v2 pose records and its complete source impact was censused once. No new pose search, domain expansion, alternate selection, cuts, physical scope expansion or native work occurred.

The fixed proposal directly affects **52 exact source objects: 46 segments and 6 vias across 23 nets**, including all prior29 segment obligations plus **23 additional objects (17 segments / 6 vias)**. The complete census records **55 selected conflict pairs, 33 original pad-contact pairs, 99 full-object same-net contact records and 56 preserved frontier objects**. Those additions reach F3 neighboring cells (including U2311 sum, D2305/R2385 clamp, REFN5 fanout), an F2 via on J900221.3/R2223.1, and two AGND vias. Existing obligations already include five +12V and five −12V contact segments. Full net ownership is a continuity review obligation, never whole-net edit permission.

**Copper reconstruction cannot repair this joint proposal:** C2337/U2312, C2338/U2312 and C2339/U2313 courtyard overlaps are0.6336/2.5536/2.1320 mm²; two moved-pad clearance failures and one conservative bypass-distance failure also remain. C2312.1 stays29.97861 mm from fixed U2306.5 (10mm is only a preference). No second selection followed. The23additional objects are an exact impact list for this pose, **not a minimum or sufficient reconstruction solution**. No minimally sufficient scope change or necessary neighboring-footprint movement has been established.

[Concise recommendation and comparison](https://github.com/Takazudo/zudo-osc-hole-field/blob/1bc168efb41c369d1598733719b6a4befcc6e7cb/design/partition/core-split/candidates/pilots/f3-copper-impact-v1/README.md), [conditional per-object reconstruction plan](https://github.com/Takazudo/zudo-osc-hole-field/blob/1bc168efb41c369d1598733719b6a4befcc6e7cb/design/partition/core-split/candidates/pilots/f3-copper-impact-v1/reconstruction-proposal.json), [complete object/branch evidence](https://github.com/Takazudo/zudo-osc-hole-field/blob/1bc168efb41c369d1598733719b6a4befcc6e7cb/design/partition/core-split/candidates/pilots/f3-copper-impact-v1/evidence/affected-objects.json), [net/pad ownership](https://github.com/Takazudo/zudo-osc-hole-field/blob/1bc168efb41c369d1598733719b6a4befcc6e7cb/design/partition/core-split/candidates/pilots/f3-copper-impact-v1/evidence/net-ownership.json), [ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/1bc168efb41c369d1598733719b6a4befcc6e7cb/design/partition/core-split/candidates/pilots/f3-copper-impact-v1/ledger.json), [independent result review](https://github.com/Takazudo/zudo-osc-hole-field/blob/1bc168efb41c369d1598733719b6a4befcc6e7cb/design/partition/core-split/candidates/pilots/f3-copper-impact-v1/evidence/result-review.json), [proposal review](https://github.com/Takazudo/zudo-osc-hole-field/blob/1bc168efb41c369d1598733719b6a4befcc6e7cb/design/partition/core-split/candidates/pilots/f3-copper-impact-v1/evidence/proposal-review.json).

Census source `511447010a84b5a1a0e8a9eba0deab03481d2d30`; reviewed deliverable `1bc168efb41c369d1598733719b6a4befcc6e7cb`. All133902 source hashes/all133551 segment-via geometries authenticated. Independent source/result/proposal reviews PASS; `pnpm check`, baseline verification and pre/post `pnpm circuit:check` PASS (manual68/zero-placement/no-schematic-binding limit). Full accepted native groups/pads beyond the fixture, zone/refill, DRC/parity and warning/eligibility gates remain **NOT RUN**. All canonical copper/boards and fixed panel/harness identities remain unchanged; no merge or closure.

**Decision boundary:** leave this proposal retired; an owner must explicitly commission a different site or revised joint-placement/copper contract before further work. No alternative site or new search is selected here. Original demands and U2309 rail blockers remain open.

---

## Prior: one copper-aware F3 repair — finite-domain infeasibility

The one authorized repair epoch completed: **16,184 poses screened; U2312 and U2313 each have zero individual survivors**, even with the other movable parts and exactly 29 conditional reconstruction segments optimistically absent. No joint placement exists in the sealed finite domain. This is not a global/continuous impossibility claim. No candidate was selected, and no joint-assignment search, routing, reconstruction, native run or adoption followed. No bound interrupted execution and the environment disconnect caused no rerun.

Same 24-reference F3/two-A closure: seven movable refs (including C2312 and C2337), seventeen fixed including U2306. Per ref: two frozen original/v1 seeds, ±2 mm x/y at 0.25 mm spacing, four orthogonal rotations, original B.Cu face (2,312 poses). Fixed courtyards, reservations, holes and all **133,551 retained accepted segments/vias** were screened; all **133,902 source object hashes** authenticated. For U2312 the 441 poses passing courtyard/reservations all failed copper (303 foreign / 138 via-SMD); U2313 likewise 464 (312 / 152).

All **67 prior pairs / 57 objects / 18 fixture-absent pairs** remain reconciled. Exact dispositions: **29 original contact segments with conditional reconstruction plans, 34 preserved objects, zero verified group transforms**. No whole-net relaxation. Full-object contacts include midsegment T/overlaps; plans retain 39 same-net copper contact records and 33 original fixture-pad contacts. No continuity reconstruction was performed. Original BP_INT/AGND demands and U2309 rail blockers remain unchanged. The 74 distinct recorded copper blockers are preserved first-refusal witnesses, not a minimum cut set or permission to expand scope.

Execution source: `4a1c3ec2ef1906ad5bfeb9a8f5ceef1f964d7b18`. Evidence commit: `905c323da7fcce9230b2fae0e37923f970ec01c1`. [Outcome and scope](https://github.com/Takazudo/zudo-osc-hole-field/blob/905c323da7fcce9230b2fae0e37923f970ec01c1/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v2/README.md), [sealed ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/905c323da7fcce9230b2fae0e37923f970ec01c1/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v2/ledger.json), [single-execution receipt](https://github.com/Takazudo/zudo-osc-hole-field/blob/905c323da7fcce9230b2fae0e37923f970ec01c1/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v2/evidence/execution-receipt.json), [independent review](https://github.com/Takazudo/zudo-osc-hole-field/blob/905c323da7fcce9230b2fae0e37923f970ec01c1/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v2/evidence/independent-review.json), [exact copper blockers](https://github.com/Takazudo/zudo-osc-hole-field/blob/905c323da7fcce9230b2fae0e37923f970ec01c1/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v2/evidence/recorded-copper-blockers.json).

**Independent review PASS:** all 16,184 domain records and all 4,624 IC rejection witnesses independently checked, together with source seals, classification and contact sets. Eight inherited duplicate copper UUIDs affect none of the classified objects; all source rows were retained. Seven focused tests, `pnpm check`, frozen-baseline verification and `pnpm circuit:check` passed. Circuit checks retain their manual68/zero-placement/no-schematic-binding limit. Inherited accepted JL117/JR129/core1402 DRC/parity0/0 receipts are not fresh native evidence. **Full regeneration, whole-chain/cross-path/refill and full-warning/eligibility gates NOT RUN.** No native slot used, canonical board change, merge or issue closure.

This epoch is complete. Routing admission remains blocked by the empty IC domains and unresolved continuity obligations. Next is exact blocker/ownership review before any explicitly revised repair contract; no further search or neighboring-group expansion is authorized by this result.

---

## Prior: one F3 integrator placement pose — source no-fit

Executed one source-only two-A F3 integrator-cluster epoch under #245, returning evidence to #253. All **24 sensitive/bypass references** are accounted for; **seven moved, seventeen fixed**, including fixed U2306. Original BP_INT **C2312.1 → U2306.5** and AGND **C2338.2 → U2312.5** identities are retained. The prior weighted-path rejection remains a path-dependent via conflict, not proof that placement had to change.

**NO FIT under the frozen source reservation policy.** Moved-component 0.35 mm same-face gaps, 0.30 mm board-edge allocation and analytic service-hole screens have zero violations, but C2338 overlaps **K-P-50-K-hook by 0.984 mm²**, and U2313 overlaps **K-P-45-K-hook by 1.7296 mm²**. Prior whole-cluster occupancy there was 2.880 and 1.7296 mm² respectively: the first decreases, the second is inherited at the reused site. Neither is waived. This is a source access-reservation failure, not new native mechanical evidence. The 10 mm proximity objective was met but is not an owner constraint or routing proof.

The source screen authenticated all **133,902 accepted object spans / 133,551 segments and vias** and records **67 new pad-to-foreign-copper clearance conflicts** (49 pairs against fixture objects, 18 against accepted objects absent from that reduced fixture), 33 old pad/object contacts, 63 directly affected objects and 26 exact net recheck selectors. The existing **C2312.1 ↔ U2312.12** connection is retained as its 44-member original group and **42 exact copper objects**. No copper was cut, adopted, or silently transplanted; zone refill and continuity remain obligations.

[Exact pose/result and continuation](https://github.com/Takazudo/zudo-osc-hole-field/blob/2e87d3d25bd7064ef60379f5b32f39c7a227b108/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v1/README.md), [ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/2e87d3d25bd7064ef60379f5b32f39c7a227b108/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v1/ledger.json), [copper accounting](https://github.com/Takazudo/zudo-osc-hole-field/blob/2e87d3d25bd7064ef60379f5b32f39c7a227b108/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v1/evidence/copper-accounting.json), [independent review](https://github.com/Takazudo/zudo-osc-hole-field/blob/2e87d3d25bd7064ef60379f5b32f39c7a227b108/design/partition/core-split/candidates/pilots/f3-integrator-cluster-v1/evidence/independent-review.json). Executed source: `f6f95aff815c87684303b1491670196ce15a9989`; published evidence: `2e87d3d25bd7064ef60379f5b32f39c7a227b108`. The one source screen took 4.546924181 seconds; no second pose or route search ran.

**Smallest justified next scope stays within the current 24 refs**: revise U2313 with its C2339/C2340 bypasses and C2338 with its U2312 relationship around the fixed hook reserves. No external-reference courtyard offender or necessary neighbor-group expansion is established. Exact replacement poses and combined signal/return geometry remain unproven. U2309 rail blockers stay explicit.

PASS: five focused tests, independent source/result review, project checks, circuit checks and frozen-baseline verification. **Whole-chain/cross-path/fill and all native acceptance gates NOT RUN after the failed placement prerequisite.** No native slot reserved, candidate board application, accepted-board adoption, architecture selection, merge or issue closure. Component scope remains manual68lines/zero declared placements without schematic binding. Full regeneration is NOT RUN because it invokes native operations outside the explicit source-only scope.

## Earlier evidence and history

## Final weight-2 attempt: invalid chain; unchanged-placement case retired

Exactly one final source experiment ran from `f5626849b368fb17cf11ccb729a6460dae43b4e0`: fixed weighted A* weight **2**, higher-g tie breaking, unchanged geometry/graph/goals/layer/via rules, shared **50,000 expansions / 250,000 exact checks**. Connectivity was verified by successful shell/GitHub reads before execution; the source checkpoint was committed and pushed first.

The search found a 272-node graph path (277 stitched nodes), then the unchanged complete emitted-chain gate rejected two new vias: **0.436103992 mm separation versus 0.700001 mm required**. It consumed **15,607 expansions / 26,251 exact checks** in a measured 4.544200353-second method interval. **No candidate was emitted.** Full cumulative-fill validation was NOT RUN because the preceding new-via gate rejected. This is neither physical-impossibility proof nor proof that component movement alone is necessary.

**The unchanged-placement case is retired. No rolling heuristic variant, budget increase, native packet/run, PCB apply or adoption follows.** [Exact result and review](https://github.com/Takazudo/zudo-osc-hole-field/blob/8b82fabd546cae859deade6c05ae110c4d0090b2/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/weighted-final/README.md), [ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/8b82fabd546cae859deade6c05ae110c4d0090b2/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/weighted-final/ledger.json). Executed source SHA remains distinct from the evidence publication SHA `8b82fabd546cae859deade6c05ae110c4d0090b2`.

Concrete next recommendation under existing #245/#253: one disposable **F3 integrator-cluster placement pilot**, initially fixing U2306 while repacking U2312/C2312 toward its BP_INT terminal. The [handoff](https://github.com/Takazudo/zudo-osc-hole-field/blob/8b82fabd546cae859deade6c05ae110c4d0090b2/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/weighted-final/placement-recommendation.md) names all **24 sensitive/bypass refs**, exact current pad/pose source, measurable proximity/access targets, combined attachment/interior-via checks and exact copper accounting. It is a recommendation only; no collision-free pose, source edit, lane assignment or architecture winner is claimed. U2309's own-pad rail blocker and AGND remain explicit.

PASS: **101 terminal-access tests**, including seven weighted-order regressions; project/circuit checks; frozen-input verification; independent source/result review. Full regeneration/native closure/DRC/parity/refill/full-warning/eligibility remain NOT RUN. Component scope remains manual68lines/zero declared placements without schematic/placement binding. All native slots are free. Fixed panel, circuit intent, complete harness identity/order, noncore poses and accepted copper are unchanged.

## Historical experiments (superseded by the final disposition above)

## Candidate-local exact transition revision: capped full-pair negative

Implemented one planar transition exception: a foreign-copper raster rejection may pass only when the existing complete exact swept-segment predicate passes. The unchanged hard edge/keepout/domain/layer gates still apply at both endpoints; diagonal side edges prevent corner cutting. Original via/hole/SMD rules and original goals remain unchanged. Shared router/adapter and all physical inputs are untouched.

A single source feasibility attempt targeted the complete original **C2312.1 → U2306.5** demand within the same frozen window/domain. It progressed beyond the old isolated pocket but stopped at **50,000 expansions**, having discovered 51,829 states and checked 199,910 exact transitions; 17,688 exact-clear foreign-raster overrides were considered. **No complete candidate or partial copper was emitted.** This is **EXPANSION_LIMIT**, not proven disconnection or physical impossibility. No unchanged retry or increased budget followed.

[Method, exact provenance and reproduction](https://github.com/Takazudo/zudo-osc-hole-field/blob/5357a4dab249f12d61c9f309d6e4c6054eabafb9/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/exact-transition/README.md), [raw consumed result](https://github.com/Takazudo/zudo-osc-hole-field/blob/5357a4dab249f12d61c9f309d6e4c6054eabafb9/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/exact-transition/result.json), [ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/5357a4dab249f12d61c9f309d6e4c6054eabafb9/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/exact-transition/ledger.json), [independent review](https://github.com/Takazudo/zudo-osc-hole-field/blob/5357a4dab249f12d61c9f309d6e4c6054eabafb9/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/exact-transition/independent-review.json). Published integration SHA: `5357a4dab249f12d61c9f309d6e4c6054eabafb9`.

The corrected gate independently passes all **130 exact-clear boundary edges** and refuses all **18 real collisions**, using the complete original input and no second feasibility search. The requested `(217.0,262.9)` → `(217.0,262.8)` mm exit retains +0.035023364 mm exact margin. The eastward collision against retained via `9bc880ec-2717-59d4-98ee-1358bf13df02` remains forbidden and caused 191 exact rejections in the consumed attempt. [Complete edge receipt](https://github.com/Takazudo/zudo-osc-hole-field/blob/5357a4dab249f12d61c9f309d6e4c6054eabafb9/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/exact-transition/edge-proof.json), [independent boundary review](https://github.com/Takazudo/zudo-osc-hole-field/blob/5357a4dab249f12d61c9f309d6e4c6054eabafb9/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/exact-transition/boundary-review.json).

Executed method SHA256 `893dd3c580cd22facad18b4244e4ba1735cfeab9d72ddc56d98f639b5c79f970` and exact test bytes are preserved in `attempt-source`. Review found and fixed a recursive diagonal counter check that could exceed the exact-check cap by one. The consumed attempt stayed below that cap (199,910 < 250,000), so its stopping condition was unaffected. A new regression verifies the fix. **No complete-pair attempt was rerun after the fix**; current-method evidence comprises regressions, source review and the no-search boundary check. The 300-second limit is a soft feasibility-search wall check, not a whole-process watchdog; the measured method interval was 20.241109658 seconds.

PASS: **94 terminal-access tests**, including eleven method regressions; independent source/result and boundary review; circuit/docs/generated-output/TypeScript checks; frozen baseline preservation. Component validation remains manual 68 lines/zero declared placements without schematic/placement binding. Full regeneration is NOT RUN because it includes unadmitted native operations.

**Stopped negative; no native run, proposal packet, PCB apply or adoption. All slots remain free.** Original rails and AGND remain explicit and unresolved. Fixed panel, circuit intent, harness IDs/references/full pin order, sensitive groups, poses and accepted copper remain unchanged. Full native closure/DRC/parity/refill/full-warning/eligibility remain NOT RUN. No architecture winner is claimed.

### Prior In2-only method: isolated region proved

The reviewed local breakout does not remove the original full-route failure. It adds a **416-node In2.Cu pocket**, but reaches **none of the six original U2306.5 goal landings**, with zero permitted via or through exits. The original 1,034 B.Cu source nodes remain unchanged; the repaired source union has 1,450 nodes and still no goal. Both actual windows are `[99,343,37,420]`; free, via and goal masks are byte-identical. The pocket does not touch the window boundary.

[Complete region proof and reproduction](https://github.com/Takazudo/zudo-osc-hole-field/blob/2be9b9144e4d7e12f78a54078c841fd433f7d2d7/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/region-stop/README.md), [ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/2be9b9144e4d7e12f78a54078c841fd433f7d2d7/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/region-stop/ledger.json), [independent review](https://github.com/Takazudo/zudo-osc-hole-field/blob/2be9b9144e4d7e12f78a54078c841fd433f7d2d7/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/region-stop/independent-review.json). Published integration SHA: `2be9b9144e4d7e12f78a54078c841fd433f7d2d7`.

All **1,444 unique permitted internal edges pass exact geometry**. The 148 cardinal boundary exits all fail the unchanged raster foreign-copper predicate; 18 also fail exact geometry and 130 are exact-clear. Thus this is a disconnected current method graph, **not physical impossibility**. Every boundary predicate, exact margin, via screen and complete named obstacle is retained against the full original input.

The immediate eastward edge `(217.0,263.3)` → `(217.1,263.3)` mm fails clearance by **0.023150681 mm** against retained via `9bc880ec-2717-59d4-98ee-1358bf13df02`, on the R2372.1/RV2311.2 net. All 416 pocket sites were checked for a new through via: ten pass exact geometry on the original input, but all are within 0.317 mm of the breakout via, so none supports a distinct added via under the existing 0.700001 mm spacing rule. Reusing the same attachment via on another layer is a separate transition question and is not implemented or credited.

**STOP this unchanged In2-only repair; no execution packet or native proposal was created.** No router A*, native search, PCB apply or hardware adoption occurred. All slots remain free. The prior local producer/proof and original empty O1/F3 proposals remain historical evidence; shared router/adapter, physical input, accepted copper, panel, circuit intent, harness IDs/references/full pin order, sensitive groups and poses are preserved. All four original demands remain; U2309 rail own-pad obstructions and AGND debt are unchanged.

PASS: **83 terminal-access tests**, including six new region regressions; six component/geometry regressions; independent graph/geometry/raster-predicate/source-seal review; circuit/docs/generated-output/TypeScript checks; baseline preservation. Component check remains manual 68 lines/zero declared placements without schematic/placement binding. Full regeneration and native closure/DRC/parity/refill/full-warning/eligibility are NOT RUN under the no-native scope. A different transition method needs its own exact reachability proof before any future packet/admission.

### Prior local breakout checkpoint — superseded by region STOP above

The retained F3/two-A source component had no raster-approved via exit. One explicit local breakout now supplies an exact-checked In2.Cu source attachment: a 0.3 mm B.Cu segment from C2312.1 `(213.7,264.1)` to `(216.8,263.3)` mm, then a 0.6/0.3 mm via. Required clearance remains 0.25 mm. This is a new named repair/input epoch, beyond the old 2 mm diagnostic templates.

[Repair, exact owners and before/after proof](https://github.com/Takazudo/zudo-osc-hole-field/blob/7be89c73e1acc429989818eba5bec1c848fcbd85/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/README.md), [ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/7be89c73e1acc429989818eba5bec1c848fcbd85/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/ledger.json), [independent review](https://github.com/Takazudo/zudo-osc-hole-field/blob/7be89c73e1acc429989818eba5bec1c848fcbd85/circuit/routing/epic-242/decision-pilots/terminal-access/local-breakout/independent-review.json). Published integration SHA: `7be89c73e1acc429989818eba5bec1c848fcbd85`.

The limiting foreign via is `5c0e2b48-e6b8-50a6-af33-fc51f5fe0026` (R2390.2/U2307.1 net); the limiting segment obstacle is R2372.2 pad `2bdd7bfd-4621-5c13-961b-81ea50c34a75`. Exact via and segment clearance surpluses are +0.071954446 mm and +0.117246531 mm. The original obstacles remain unchanged. A nearby negative control fails clearance and is rejected.

Signal goal/source portal counts change from 6/3 to 6/4. The new source marker permits In2.Cu only; all four adjacent In2 lattice nodes pass unchanged raster track predicates and exact geometry checks. This proves a usable local handoff, **not complete-pair reachability**. The existing adapter emits the attachment once only after full-pair success and geometry/fill checks; failed searches emit none. The unchanged original dump is authenticated, and no preview via is staged into it.

PASS: all **77 terminal-access source tests**, seven independently rerun repair regressions, exact before/after transition proof with A* intercepted before search, independent source review, circuit/docs/generated-output/TypeScript checks, and frozen baseline verification (1,881 original inputs plus two reviewed tool replacements; 195 harnesses/390 complete endpoints). Component check scope remains manual 68 lines/zero declared placements, without schematic/placement binding.

**Parent accepted the F3/two-A negative result and released reservation1641; all native slots are free. Unchanged O1/F3 trials are stopped.** This commit adds no native execution wrapper or workflow. Shared router/adapter, physical dumps, panel, circuit intent, harness IDs/references/pin order, poses and accepted copper remain unchanged. No package move, cut, PCB apply or adoption occurred.

Full-pair routing, fresh native closure/DRC/parity/refill/full-warning/eligibility remain **NOT RUN**. A future native trial requires a newly sealed repair-method/input packet and explicit parent admission; the old frozen fixture lock cannot cover this pool. Rail/return debts remain: U2309 supply starts are constrained by its own adjacent pads, and AGND has no legal via among its 149 reachable B.Cu grid sites. No architecture winner is claimed.

## F3 matched comparison: both bounded routes produced no improvement

The single admitted F3/two-A run completed at the exact source and limits: **zero additions, cuts or links; all four demands unresolved**. [Run38156907050](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38156907050), job114521653053, attempt1, admission`epic242-f3-two-a-route-20261011-1641`. No retry or follow-on phase occurred.

Orchestration`791195aac846841926357c480894421fff562b9e`; frozen method`6f0783335fa23d760877a91db3b63f93c039b4b4`; two-A fixture lock`00dd82fa7c42d770204b0177e1f48eb0592a6595696b16bf8f9a76ae4c729f60`. Execution branch`integration/epic-242-f3-two-a-access-v1` is frozen and must not be pushed again, recreated or rerun.

| Original demand | K1402 portals | Two-A portals | Result on both |
|---|---:|---:|---|
| +12V U2309.4 → C2331.1 | 0/6 | 0/12 | No valid saved access |
| −12V U2309.11 → C2332.1 | 0/3 | 0/6 | No valid saved access |
| AGND C2338.2 → U2312.5 | 3/3 | 3/3 | Search exhausted,149 expansions |
| BP_INT U2306.5 → C2312.1 | 3/3 | 6/3 | Search exhausted,1077 expansions |

The larger two-A landing pool produced no complete route under the same bounds, windows and50000-expansion cap. Both proposals are empty and unapplied. This establishes neither physical impossibility nor an architecture winner; rail/return debt remains explicit. K1402 reservation1623 is already released.

**Independent retained-evidence review PASS; no cleanup blocker to parent release of1641.** Peak323,182,592bytes, minimum sampled free15,322,365,952bytes across42samples, all memory-limit/OOM counters0. Both full-ID probe ACK/livePID/cgroup/retained-exit0 proofs passed. Guard/driver exits0; no containers, three not-found/inactive/settled units, no final errors or cleanup failures. Adapter wall38.427836002s includes geometry/validation; last guard sample43.234602684s within the unchanged300-second phase including both probes.

Actual-host setup/history/Python3.11.17/pinned dependencies/image verified. Complete recovery artifact,427source/control hashes and297fixturefiles authenticated before/after;203original before/context bytes preserved. [Full artifact11709240803](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38156907050/artifacts/11709240803):17,573,972bytes,SHA256`552347595d8d0dd2bcca5437cbf83cb31ce92ea96cb8a395598faaa493240040`; all317CRCs/extractedbytes pass. Raw proposals,diagnostics,input/control/container/resource/cleanup receipts and full decoded logs retained.

[Closeout ledger and independent review](https://github.com/Takazudo/zudo-osc-hole-field/blob/7982815025b1e9a79491c369e2dc977eab9953e5/circuit/routing/epic-242/decision-pilots/terminal-access/route-1641/README.md). Pushed integration/evidence SHA:`7982815025b1e9a79491c369e2dc977eab9953e5`. Post-run circuit/docs/generated-output/TypeScript and baseline checks pass;70 prelaunch source tests,including19binding tests,passed. Component scope:manual68lines,zero declaredplacements; no schematic/placement binding. No fresh nativeboard closure,DRC/parity,full-warning or eligibility gates ran.

**Parent accepted the negative result and RELEASED reservation1641; all native slots are free. Unchanged O1/F3 matched trials are stopped.** Apply,settle,fresh-copy,full-warning audit,adoption and further native runs remain unadmitted. No hardware change,merge,closure,deployment or fabrication. Accepted main`65cefd41fc39e064d38319115ad96016a1c6b71c` remains JL117/JR129/K1402 with inheritedDRC/parity0/0; fixedpanel,circuits,harnessIDsRefsfullpinorder,noncoreposes and retained copper are unchanged. Core1312 remains unadopted.

### Prior F3/E1 bounded source pass — 191a4db

[Per-demand results, exact obstruction owners and reproduction](https://github.com/Takazudo/zudo-osc-hole-field/blob/191a4db30d90fe43025ec2633e23f9b069f12b85/circuit/routing/epic-242/decision-pilots/terminal-access/cohort-report.md). Existing validator and all original demands/rules are unchanged. All five retained ZIPs/board/dump bindings authenticate; 24 board/demand rows remain BOTH_OPEN from complete native-group receipts, with 48 exact anchor records.

**First informative comparison for review: F3 K1402 versus two-A.** The original signal U2306.5 → C2312.1 and return pair have legal straight local escapes at both terminals. U2306.5 additionally has 167 valid edge-plus-via witnesses on two-A (99 on three-B), versus zero within the identical K1402 templates. A retained candidate witness fails on K1402 against exact −12V via `0f9ff359-2b0a-56f9-94e7-82b2c291d170`. E1 C4163.2 also has a candidate-positive/K-negative witness, blocked on K by −12V via `21450344-420f-5d43-b321-10a4fda4a2e0`. The incumbent copper is retained. Positive access on both boards or new vias at both terminals are not required.

The shared center-inside rail obstructions resolve to same-package pads: F3 U2309.4 against .3/.5 and U2309.11 against .10/.12; E1 U4141.4 against .3/.5 and U4141.11 against .10/.12. E1 AGND U4141.12 is constrained by .11/.13. Whole-pad bound ≤0.461395002 mm versus 0.5 mm required. Center-inside contact and ≤2 mm straight templates are diagnostic assumptions, not owner-fixed physical constraints. Adequate off-pad contact, longer/curved escapes and complete routes remain unproved. No demand was dropped or replaced.

**At this earlier checkpoint there was no integrated method or native packet.** F3's asymmetric evidence is useful; all four demands need not succeed to make a comparison informative. The remaining gap is implementation/review: the exact validator is standalone, and the unchanged raster router need not exercise these witnesses. Exact routing-method treatment and a precise request require separate review. No O1 repeat or budget increase.

PASS: 15 unit tests; independent full replay of all 24 rows/48 endpoints; all 60 cross-board witness/obstacle checks; frozen source/evidence bindings; baseline preservation; circuit/docs/TypeScript. Component scope: manual 68 lines/zero declared placements, no schematic/placement binding. Fixed panel, successful copper and hardware unchanged; no native execution/admission, no merge or closure.

### Prior exact terminal access and conditional headroom checkpoint

[Reviewed source, reproducible findings and closeout](https://github.com/Takazudo/zudo-osc-hole-field/tree/63dfa62e302b214d67fae9e22ac2f5dc3a753b74/circuit/routing/epic-242/decision-pilots/terminal-access). Same authenticated K1402/two-A O1 inputs and exact anchors; unchanged 0.5/0.3 mm widths, 0.25 mm clearance and 0.6/0.3 mm vias. Full swept edges, strict named-anchor contact and all-layer via checks preserve original obstacles and successful copper. No router/A*/KiCad/native execution or production-method change.

Both U1109 supply pads have continuous whole-pad center-clearance upper bound **0.461395002 mm**, below **0.5 mm** required for the full-width center-inside contact policy. This is a floating engineering enclosure, not physical impossibility or an exclusion of separately justified off-pad contact. AGND U1105.12 has 108 legal start caps but zero valid straight escapes in the finite ≤2 mm template set. Earlier pointwise raster false exclusions are insufficient to certify a swept escape.

Eighteen retained local edge-plus-via witnesses were independently checked at identical coordinates on the other board. All edges pass both; some two-A vias fail K's existing-hole or foreign-copper constraints. These are local geometric differences, not completed connections or architecture gains. **No corrected four-demand native packet is justified yet.** Next source work must establish adequate unchanged-width off-pad contact or screen the already defined F3/E1 BOTH_OPEN cohorts; no budget increase or disconnected-graph rerun.

[Conditional collet headroom and qualification ledger](https://github.com/Takazudo/zudo-osc-hole-field/blob/63dfa62e302b214d67fae9e22ac2f5dc3a753b74/circuit/routing/epic-242/decision-pilots/feed-arrangement/collet-headroom.md): **0.197966035 mm** is one shared conditional local allowance, not a separate budget for each tolerance. All eleven qualification items remain false. Local angular clearance cannot relax C1/C2, bend or cut/preparation requirements. Complete collisions, supplier/process/material/retention and physical qualification remain open.

PASS: 12 terminal-access tests, 31 feed tests, deterministic headroom check, independent geometry/base-report/cross-board review, evidence hash bindings, baseline verifier, circuit/docs/TypeScript checks. Component scope: manual 68 lines / zero declared placements, no schematic/placement binding. Hardware remains unchanged. Both empty proposals remain unapplied; reservations1420/1438 released by parent, all native slots free. Fresh native/full-warning/eligibility gates remain unadmitted.

### Prior source-only diagnosis and clearance checkpoint

[Complete diagnosis and reproduction](https://github.com/Takazudo/zudo-osc-hole-field/tree/c163dd4704c16750a618b6748c205f301ca9482e/circuit/routing/epic-242/decision-pilots/diagnosis-o1). No route/A*/KiCad execution: exact retained mask components were reconstructed with frozen source/input/version authentication and independently reproduced byte-for-byte.

| Demand | Diagnosis common to both boards |
| --- | --- |
| +12V | U1109.4 is a59-cell terminal-only component:0freeexits/0vias. two-A gains source-side free space but cannot enter this same goal. |
| -12V | U1109.11 is a56-cell terminal-only component:0freeexits/0vias. |
| AGND |50000search cap masked an isolated145-cell F.Cu goal, with0vias. Increasing budget cannot connect the unchanged graph. |
| TRI_SUM | Identical separate395-cell/705-cell B.Cu components, each with0vias. |

All four graphs are disconnected in every recorded window. The exact-geometry point-clearance screen still rejects every immediate0.1mm-grid supply-goal boundary center at unchanged0.5mm width/0.25mm clearance. AGND/signal have22 and73/139clear centers rejected by conservative raster inflation. These are pointwise witnesses, not swept-route/contact/via proofs. The sample is blocked by shared local terminal constraints and cannot select an architecture. It does not prove physical impossibility or mandate a placement change.

At that checkpoint, the smallest justified next step was source-only exact-polygon terminal-contact plus swept-edge/via checker on the same four demands, unchanged widths/clearance/electrical rules and preserved copper. Require finite-width escape/contact evidence before another method revision or native request; no budget increase, repeat or easier/already-connected pair. **No new native request justified yet.** Both reservations released and empty proposals unapplied.

[Conditional collet clearance](https://github.com/Takazudo/zudo-osc-hole-field/blob/c163dd4704c16750a618b6748c205f301ca9482e/circuit/routing/epic-242/decision-pilots/feed-arrangement/collet-clearance.md): exact flat-ended cylinder with a proposed conditional axis cone and all independent closures leaves0.447966035mm to own board against0.25mm required.12collets screened against2430listed reservations yield minimumXYgap3.233303944mm. No geometry/hardware/copper change. Arms/joints, wire-to-collet/arm, completefeed, material/retention/shape and physical qualification remain OPEN.

PASS:6diagnostic tests,23feed tests, independent full diagnosis reproduction, deterministic collet receipt, baseline verifier and circuit/docs/TypeScript checks. Manualcomponent inventory scope68lines/0placements with no schematicbinding. Native and physical gates remain unrun for this source-only checkpoint.

### Matched O1/two-A1438 result

[Run38148185181](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38148185181), job114495848565, worker `o1-two-a-r1438-38148185181-1`, ran once under `epic242-o1-two-a-route-20261011-1438`. Launcher `ab94128d779803fb10ecf2196a2b83f2c4081f5b`; isolated orchestration `0a9dd48e16002db1335abc451ed63954d919fd66`; frozen method29140d4e and hook unchanged. Execution branch is frozen. No proposal was applied.

| Matched bounded experiment | K1402 /1420 | two-A /1438 |
| --- | --- | --- |
| Additions / cuts / links | 0 / 0 / 0 | 0 / 0 / 0 |
| Unrouted demands | 4 | 4 |
| +12V / -12V / TRI_SUM | searches exhausted | searches exhausted |
| AGND | expansion limit | expansion limit |
| Search seconds | 9.273817893 | 4.688842146 |

Same four exact O1 demands/polygons, bounds, method, numerical versions, clearance, windows and caps; separately authenticated original boards. Neither negative result establishes impossibility or split advantage. Separate-runner time/memory differences are descriptive only. No new native closure/DRC/parity/full-warning/eligibility acceptance.

[Ledger, raw logs, fixture lock, proposals/diagnostics and complete receipts](https://github.com/Takazudo/zudo-osc-hole-field/tree/9a77da63cb7089813ec59e3688d712ba0c44966b/circuit/routing/epic-242/decision-pilots/route-1438). [Full artifact11705755937](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38148185181/artifacts/11705755937):20,195,283bytes; SHA256 `ed8de7933f40369ecefb3ea28f382662923b414298e0cdb72ed5e32578e64e3f`. Independent review PASS:319CRCs,297unchanged input hashes,14primary+418method hashes,six fullZIPbindings,exacttwo-Aoriginal/payload,both full-ID ACK/livePID/cgroup/retained-exit0 and complete cleanup.

Whole-worker peak235,540,480bytes; minimum sampled free15,386,996,736bytes,10samples; memoryevents all0. Final containers[],3owned units inactive/not-found/settled,errors[],cleanupfailures[]. **Reservation1438 was subsequently RELEASED BY PARENT; all slots are free.** Source gate PASS plus38tests, baseline verifier,circuit/docs/type,YAML/bash and final artifact/receipt/ledger integrity. Scope of component check remains manual68lines/0declaredplacements without schematic/placement binding. Stop after route; apply/settle/fresh/full-warning audit remain **UNADMITTED**. KEEP_K1402_INCUMBENT.

### Reconciled feed checkpoint

[Process/datum/tolerance requirements](https://github.com/Takazudo/zudo-osc-hole-field/blob/c4a4e82465089e007448574619f5e9ef617f2ac0/circuit/routing/epic-242/decision-pilots/feed-arrangement/process-budget.md), [generated reconciliation overlay](https://github.com/Takazudo/zudo-osc-hole-field/blob/c4a4e82465089e007448574619f5e9ef617f2ac0/circuit/routing/epic-242/decision-pilots/feed-arrangement/reconciled-contract.json), [reproducible curve evidence](https://github.com/Takazudo/zudo-osc-hole-field/blob/c4a4e82465089e007448574619f5e9ef617f2ac0/circuit/routing/epic-242/decision-pilots/feed-arrangement/robust-curve.json).

The integration-owned overlay binds the historical #246/#247 producer hashes and preserves the complete ordered CS247 wire/terminal records. KA B.Cu→KB F.Cu is permitted source design; F/F was a provisional generator choice. Historical lane producers remain unchanged. New proposed geometry uses58mm offset,2mm raised anchors and66mm free reference length. A machined dielectric split-collet/carrier process, board/optical datums and explicit worst-case closure budgets replace the formerly unspecified tolerance assumptions. No supplier capability is claimed.

Across proposed gap20.2..30.7mm and reference length65.9..66.1mm, floating engineering bounds give reference radius≥28.737350mm. Conditional continuous C0≤0.20mm/C1≤0.01/C2≤0.002/mm shape limits give radius≥26.634658mm against25.908mm required. New cut84.75±0.25mm leaves≥5.085133mm preparation, including full C1 length growth. Main cuts103.75±0.25mm and stronger global rail/return copper targets0.1/0.1mΩ give worst drop19.8119mV, margin0.1881mV. These are conditional design requirements, not actual wire-shape/copper/cut qualification.

The unselected KB monitor reserve moves to[120,12,140,32], source clearance9.7mm. Complete revised arm/joint/collet/wire collision sweeps, actual shape/retention/insulation/thermal behavior, factory process capability, realized hot copper, all100 adjustment access and physical fit remain OPEN. The older52mm nominal arrangement/preview stays historical; its0.145mm nominal arm gap does not meet the new0.60mm nominal requirement and is not reused as acceptance.

### First admitted native route: capability blocked

Admission `epic242-o1-k1402-route-20261011-1347` covered ONLY O1/K1402 route300s, including both gated Docker probes, at exact method `29140d4e19d526eed3a02a73c33f8ce4219c78f0`. [Actions run38145097428](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38145097428) used isolated orchestration `5d2ace3fd3d7bc6334b4f030d62033dbd1903d87`. Clean method HEAD and all12 input hashes matched. PID1/systemd, Docker cgroupv2, memory controller and sudo passed; required outer heavy-guard and locally prepared pinned KiCad image were missing. No replacement controls, image pull or retry followed.

**Route NOT STARTED:0native workers,0probe containers, no task-created units.** SixZIP authentication, fixture preparation and execution-host numerical binding were not begun. No proposal/diagnostics or routing outcome exists for this attempt. Parent notified that the exclusive reservation is releasable. Two-A/apply/settle/fresh/audit remain unadmitted.

[Receipt and full decoded log](https://github.com/Takazudo/zudo-osc-hole-field/tree/c4a4e82465089e007448574619f5e9ef617f2ac0/circuit/routing/epic-242/decision-pilots/route-1347). [Artifact11704591168](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38145097428/artifacts/11704591168):4578bytes, SHA256 `a9e17909f736bd951f26714c90efd48c2abfa974225071702ed82b525b7d64b9`, locally verified after connector download. Direct gh transport403 was overcome by the connected GitHub download; no credentials created. Future native `--evidence` is corrected to a NEW JSON FILE.

The exact matched-demand/method packet remains pinned to29140d4e, with identical four BOTH_OPEN targets and budgets for K1402/two-A. Global≤2workers/12GiB, each≤6GiB/no swap,≥2GiB free, existing43min job cap, no retry/fallback/cuts/bounds changes. Every next phase requires parent coordination/admission. Count decreases alone cannot establish matched closure or adoption.

### Prior provisioning correction verified

[Source diagnosis, exact controls and renewal requirements](https://github.com/Takazudo/zudo-osc-hole-field/blob/23fb496a8acb655a183731b5b819a8e4dc035240/circuit/routing/epic-242/decision-pilots/provisioning/README.md). Source fix `59b0c2c21ccf2ded58cd2031e4a4289d546feca3` reuses the existing frozen `with_route_guard.sh` hosted-runner policy and `settle_only_pilot.prepare_image`. The earlier preflight incorrectly required a developer HOME guard on isolated Actions and inspected the image before provisioning. No substitute guard, native-method change or relaxed limit was introduced. Authenticated successful two-A/two-B artifacts establish the exact native guard/image-preparation provenance.

[Provision-only run38146298766](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38146298766) PASS, orchestration `84339974f72e77f6bcf4e0edb72eb5b6b7356005`: actual Python3.11.17 with numpy2.2.6/scipy1.15.3/shapely2.1.2,14source hashes unchanged, official pinned image digest/ID authenticated, pull exit0.101daemon-accounting samples: minimum free15,282,429,952bytes and peak backend3,128,696,832bytes. Sampled image-preparation thresholds are not a new native kernel-cap qualification. **0native workers/0probe containers; no fixture or route executed.**

[Artifact11705061761](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38146298766/artifacts/11705061761):10,371bytes, SHA256 `d9e24a42e4d173cf56f7fc7f5e2eaead8a8677c7d0636ab3774718185e109fea`. FullZIP SHA/size/CRC,7members, source/driver hashes and receipts independently verified. Exact JSON members and complete logs retained in the integration commit.28decision/provision tests, existing dispatch-boundary test, YAML/shell checks, all14frozen bindings, baseline verifier, circuit and docs/type checks pass.

Admission1347 is **RELEASED**. At that checkpoint, a renewed route required new parent ID/worker/capacity reservation, provisioning repeated on the fresh execution host, all six fullZIPs authenticated, exact O1/K1402 fixture lock and before hashes, and new guard JSON file. Provisioner emits reviewable argv but has no route execution branch. Method29140d4e,300s route including both probes, native6GiB/no-swap/12GiB aggregate/2GiB floor and cleanup controls remain frozen. Two-A/apply/settle/fresh/audit remain unadmitted. Geometry atc4a4e824 and all prior refusal/hardware bytes are unchanged.

### Renewed admission1420: NO IMPROVEMENT

Parent admission `epic242-o1-k1402-route-20261011-1420` ran exactly once in [Actions38147266896](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38147266896), job114493143724, worker `o1-k1402-r1420-38147266896-1`. Launcher `b4d744f950eb5e68de6849ee3b34c387dc2ab960`, isolated orchestration `1c787de02197c87b9eb299f3e5ac5e8171e49a12`, frozen method `29140d4e19d526eed3a02a73c33f8ce4219c78f0`. Actual execution-runner provisioning and all six complete ZIPs passed; the execution branch is frozen.

**Zero additions, zero cuts, zero links; four demands remain unrouted.** Search9.273817893s. Three searches exhausted; AGND reached50000expansions (diagnostic50001 follows the frozen pre-expansion check). Existing internal supply windows are not workflow retries or expanded common bounds. No follow-on phase ran and no new native closure/DRC/parity/full-warning/eligibility or architecture acceptance is claimed.

[Evidence ledger and complete receipts](https://github.com/Takazudo/zudo-osc-hole-field/tree/241821e4acba81d0149879bf32daa207d94ca314/circuit/routing/epic-242/decision-pilots/route-1420). [Artifact11705153530](https://github.com/Takazudo/zudo-osc-hole-field/actions/runs/38147266896/artifacts/11705153530):39,091,217bytes, SHA256 `9232ff3212f41604a72b3f49a9d3a8b10884186884bf50f367a57693a7e082a5`. Independent review verified319CRCs,297unchanged retained input hashes,14primary sources, six artifact bindings, both full-ID ACK/livePID/cgroup/retained-exit0 proofs, exact300s total and6GiB/no-swap controls.418transitive method tool hashes also match frozen git source.

Whole-worker peak415,399,936bytes; minimum sampled free15,253,454,848bytes; no OOM or cleanup failure. Final containers absent; all3owned units inactive/not-found/settled; errors[]. **Reservation1420 was subsequently RELEASED BY PARENT.** Raw logs, fixture lock, proposal/diagnostics, initial/final hashes and guard receipt are committed; large fixture bytes remain in the authenticated artifact.33decision/provision/receipt tests, baseline verifier, circuit/docs/type checks passed before dispatch; final exact-copy/ledger/JSON/diff checks pass. At1420 closeout two-A/apply/settle/fresh/audit were unadmitted; only the subsequent1438 route described above was then admitted. No automatic retry.

### Integration and validation

Mechanical PR270 source`b3d72e107c166e472ba6fe6476d34304e807b4ad` integrated as`e23bba91d869ad19d453d0d9c016825458d61ed8`; power PR271 source`d7b4deed4a35a609978403fbfa45330fe1e544ee` as`831cd8cfee9fd0fc27d401148aea8995e6d78d67`. Their owned paths and historical decision/contract inputs remain unchanged by this checkpoint.

PASS:16geometry/counterexample tests,24decision tests, deterministic curve/overlay reproduction, baseline verifier, pnpm circuit:check, generated documentation/models/previews and TypeScript. Independent Astra High construction and separate baseline review reproduced the new curve evidence. Baseline verification preserves1881original inputs+2reviewedtoolreplacements,195harnesses/390completeendpoints. Component validation is manual inventory68lines/0declaredplacements; schematic/placement binding was not performed. Integration commit uses `[skip ci]`; the isolated Actions capability run failed as described, not as a geometry/test failure.

Architecture remains **BLOCKED_ARCHITECTURE_SELECTION / KEEP_K1402_INCUMBENT**. Complete original audit/final gates remain with #244; native gates with #249. Draft only: no merge, issue closure, deployment, fabrication/order or energization.





🤖 Generated with [Claude Code](https://claude.com/claude-code)
